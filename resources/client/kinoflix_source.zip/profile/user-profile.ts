export interface UserProfile {
  city: string;
  country: string;
  description: string;
}
