export const TitlePageSections = [
  'episodes',
  'seasons',
  'videos',
  'images',
  'reviews',
  'cast',
  'news',
  'related',
] as const;
